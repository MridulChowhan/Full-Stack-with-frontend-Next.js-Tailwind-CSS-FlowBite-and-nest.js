'use client';
import Link from 'next/link';
import React from "react";

export default function page() {
  return (
    <div>
      <nav className="bg-blue-600 py-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center px-6">
          <div className="text-white text-2xl font-bold">E-Health Care Services</div>
          <div className="flex space-x-6">
            <Link href="/" className="text-white hover:text-gray-300">Home</Link>
            <Link href="../login" className="text-white hover:text-gray-300">Registration & Login</Link>
            <Link href="../contact" className="text-white hover:text-gray-300">Contact</Link>
          </div>
        </div>
      </nav>
      <section className="bg-[url('/service3.svg')]">
      <section className="py-24">
        <div className="container mx-auto text-center">
          <h2 className="text-3xl font-semibold text-blue-600 mb-8">Our Services</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="bg-white shadow-lg rounded-lg p-6">
              <h3 className="text-xl font-semibold text-blue-600 mb-4">Telemedicine</h3>
              <p>Consult with doctors from home.</p>
            </div>
            <div className="bg-white shadow-lg rounded-lg p-6">
              <h3 className="text-xl font-semibold text-blue-600 mb-4">Emergency Services</h3>
              <p>Available 24/7 for emergencies.</p>
            </div>
            <div className="bg-white shadow-lg rounded-lg p-6">
              <h3 className="text-xl font-semibold text-blue-600 mb-4">Health Checkups</h3>
              <p>Regular checkups for better health.</p>
            </div>
          </div>
        </div>
      </section>
      </section>
    </div>
  );
}
