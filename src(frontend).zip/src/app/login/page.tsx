'use client';

import Link from 'next/link';
import React, { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function LoginPage() {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  const [error, setError] = useState('');
  const router = useRouter();

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
    setError('');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const response = await fetch('http://localhost:4000/reg/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      const result = await response.json();

      if (response.ok) {
        // Save the token in localStorage
        localStorage.setItem('authToken', result.token);

        // Redirect to dashboard or another protected route
        router.push('/dashboard');
      } else {
        setError(result.message || 'Invalid email or password. Please try again.');
      }
    } catch (error) {
      console.error('Error during login:', error);
      setError('An error occurred. Please try again.');
    }
  };

  return (
    <div>
      <nav className="bg-blue-600 py-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center px-6">
          <div className="text-white text-2xl font-bold">E-Health Care Services</div>
          <div className="flex space-x-6">
            <Link href="/" className="text-white hover:text-gray-300">Home</Link>
            <Link href="/services" className="text-white hover:text-gray-300">Services</Link>
            <Link href="/contact" className="text-white hover:text-gray-300">Contact</Link>
          </div>
        </div>
      </nav>
      <div className="min-h-screen bg-gray-100 flex items-center justify-center">
        <form
          onSubmit={handleSubmit}
          className="bg-white p-8 rounded-lg shadow-md w-full max-w-md"
        >
          <h2 className="text-2xl font-bold mb-6 text-gray-800 text-center">Login</h2>
          <div className="mb-6">
            <label htmlFor="email" className="block mb-2 text-sm font-medium text-gray-900">
              Email address
            </label>
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className="bg-gray-50 border border-gray-300 rounded-lg block w-full p-2.5"
              placeholder="abcd@gmail.com"
              required
            />
          </div>
          <div className="mb-6">
            <label htmlFor="password" className="block mb-2 text-sm font-medium text-gray-900">
              Password
            </label>
            <input
              type="password"
              id="password"
              name="password"
              value={formData.password}
              onChange={handleChange}
              className="bg-gray-50 border border-gray-300 rounded-lg block w-full p-2.5"
              placeholder="•••••••••"
              required
            />
          </div>
          {error && <p className="text-red-500 text-sm mb-4">{error}</p>}
          <button
            type="submit"
            className="w-full bg-blue-700 text-white px-5 py-2.5 rounded-lg hover:bg-blue-800"
          >
            Login
          </button>
          <p className="mt-4 text-sm text-gray-600 text-center">
            Don't have an account?{' '}
            <Link href="../registration" className="text-blue-600 hover:underline">
              Register
            </Link>
          </p>
        </form>
      </div>
    </div>
  );
}
