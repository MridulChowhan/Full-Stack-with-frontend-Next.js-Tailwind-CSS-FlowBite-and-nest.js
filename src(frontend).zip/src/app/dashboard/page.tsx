'use client';
import { useState, useEffect } from 'react';
import { Avatar, Dropdown, Navbar } from 'flowbite-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';

export default function DashboardPage() {
  const [user, setUser] = useState({
    name: '',
    email: '',
    password: '',
    phoneNumber: '',
    address: '',
    nidNumber: '',
    dateOfBirth: '',
    gender: '',
  });
  const [payments, setPayments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const router = useRouter();

  useEffect(() => {
    const fetchUserData = async () => {
      const token = localStorage.getItem('authToken');
      if (!token) {
        router.push('/login');
        return;
      }

      try {
        
        const userResponse = await fetch('http://localhost:4000/reg/me', {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!userResponse.ok) throw new Error('Failed to fetch user data');

        const userData = await userResponse.json();
        setUser(userData.data || userData);

        
        const paymentsResponse = await fetch('http://localhost:4000/payment', {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!paymentsResponse.ok) throw new Error('Failed to fetch payments');

        const paymentsData = await paymentsResponse.json();
        setPayments(paymentsData);
      } catch (error) {
        console.error('Error fetching data:', error);
        setError(error.message);
        localStorage.removeItem('authToken');
        router.push('/login');
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();
  }, [router]);

  const handleLogout = () => {
    localStorage.removeItem('authToken');
    router.push('/login');
  };

  if (loading) return <div className="min-h-screen flex items-center justify-center">Loading...</div>;
  if (error) return <div className="min-h-screen flex items-center justify-center text-red-500">Error: {error}</div>;

  return (
    <div className="min-h-screen flex flex-col bg-gray-100">

      <Navbar className="bg-blue-700 text-white">
        <Navbar.Brand href="#" className="text-white font-bold text-xl">
          E-Health Care Dashboard
        </Navbar.Brand>
        <div className="flex-grow" />
        <Dropdown
          label={
            <Avatar
              rounded={true}
              size="md"
              placeholderInitials={user.name[0] || ''}
            />
          }
          inline={true}
          arrowIcon={true}
        >
          <Dropdown.Header>
            <span className="block text-sm font-bold">{user.name}</span>
            <span className="block text-sm font-light">{user.email}</span>
          </Dropdown.Header>
          <Dropdown.Item>
            <Link href="../editinfo">Edit Information</Link>
          </Dropdown.Item>
          <Dropdown.Item>
            <Link href="../logout">Log Out</Link>
          </Dropdown.Item>
        </Dropdown>
      </Navbar>


      <div className="flex flex-1">
        
        <aside className="w-64 bg-blue-700 text-white flex flex-col p-6">
          <div className="flex items-center space-x-4 mb-6">
            <Avatar
              rounded={true}
              size="lg"
              placeholderInitials={user.name[0] || ''}
            />
            <div>
              <p className="text-xl font-bold">{user.name}</p>
              <p className="text-sm">{user.email}</p>
            </div>
          </div>
          <nav className="flex-1 space-y-4">
            <Link href="../appointmentbooking" className="block py-2 px-4 rounded-lg hover:bg-blue-800">
              Appointment Booking
            </Link>
            <Link href="../allbooking" className="block py-2 px-4 rounded-lg hover:bg-blue-800">
              View All Appointments
            </Link>
            <Link href="../prescription" className="block py-2 px-4 rounded-lg hover:bg-blue-800">
              View Prescription
            </Link>
            <Link href="../healthrecord" className="block py-2 px-4 rounded-lg hover:bg-blue-800">
              Health Records
            </Link>
            <Link href="../allrecords" className="block py-2 px-4 rounded-lg hover:bg-blue-800">
              All Health Records
            </Link>
            <Link href="../payment" className="block py-2 px-4 rounded-lg hover:bg-blue-800">
              Payment
            </Link>
            <Link href="../logout" className="block py-2 px-4 rounded-lg hover:bg-blue-800">
              Logout
            </Link>
          </nav>
        </aside>

        <main className="flex-1 p-8">
          <div className="bg-white shadow-lg rounded-lg p-6">
            <h1 className="text-2xl font-bold text-gray-800 mb-4">
              Welcome, {user.name}, You login email is: <u>{user.email}</u>
            </h1>
            
          </div>

       
          <div className="mt-8">
            <h2 className="text-xl font-bold text-gray-800 mb-4">Your Payments</h2>
            {payments.length > 0 ? (
              <ul className="space-y-4">
                {payments.map((payment) => (
                  <li key={payment.id} className="bg-white shadow-lg rounded-lg p-4">
                    <p className="font-semibold">Amount: ${payment.amount}</p>
                    <p>Date: {payment.paymentDate}</p>
                    <p>Doctor: {payment.doctorName}</p>
                  </li>
                ))}
              </ul>
            ) : (
              <p>No payments found.</p>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}