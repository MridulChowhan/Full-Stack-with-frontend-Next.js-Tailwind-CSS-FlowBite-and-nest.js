'use client';

import { useEffect, useState } from 'react';
import { Card, Label, TextInput, Button, Textarea, Select } from 'flowbite-react';
import { useRouter } from 'next/navigation';

export default function EditInformationPage() {
  const [userInfo, setUserInfo] = useState({
    email: '',
    name: '',
    phoneNumber: '',
    nidNumber: '',
    address: '',
    dateOfBirth: '',
    gender: '',
  });
  const [isEditing, setIsEditing] = useState(false);
  const router = useRouter();

 
  const getUserIdFromToken = () => {
    const token = localStorage.getItem('authToken');
    if (!token) return null;

    try {
      const payloadBase64 = token.split('.')[1]; 
      const decodedPayload = JSON.parse(atob(payloadBase64));
      return decodedPayload.id; 
    } catch (error) {
      console.error('Error decoding token:', error);
      return null;
    }
  };

 
  const isTokenExpired = () => {
    const token = localStorage.getItem('authToken');
    if (!token) return true;

    try {
      const payloadBase64 = token.split('.')[1];
      const decodedPayload = JSON.parse(atob(payloadBase64));
      return Math.floor(Date.now() / 1000) >= decodedPayload.exp;
    } catch (error) {
      console.error('Error decoding token:', error);
      return true;
    }
  };

  useEffect(() => {
    const fetchUserInfo = async () => {
      const token = localStorage.getItem('authToken');
      if (!token || isTokenExpired()) {
        localStorage.removeItem('authToken');
        alert('Session expired. Please log in again.');
        router.push('/login');
        return;
      }

      const userId = getUserIdFromToken();
      if (!userId) {
        router.push('/login');
        return;
      }

      try {
        const response = await fetch(`http://localhost:4000/reg/${userId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        if (!response.ok) {
          throw new Error('Failed to fetch user info');
        }

        const { data } = await response.json();
        setUserInfo({
          ...data,
          dateOfBirth: data.dateOfBirth ? new Date(data.dateOfBirth).toISOString().split('T')[0] : '',
        });
      } catch (error) {
        console.error('Error fetching user info:', error);
        router.push('/login');
      }
    };

    fetchUserInfo();
  }, [router]);

  // Handle input changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserInfo((prev) => ({ ...prev, [name]: value }));
  };

  // Handle form submission
  const handleSubmit = async () => {
    const token = localStorage.getItem('authToken');
    if (!token || isTokenExpired()) {
      alert('Session expired. Please log in again.');
      router.push('/login');
      return;
    }

    const userId = getUserIdFromToken();
    if (!userId) {
      router.push('/login');
      return;
    }

    try {
      const response = await fetch(`http://localhost:4000/reg/update/${userId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(userInfo),
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('Failed to update:', errorText);
        throw new Error('Failed to update information');
      }

      alert('Information updated successfully!');
      setIsEditing(false);
      router.refresh();
    } catch (error) {
      console.error(error);
      alert('Error updating information');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-100">
      <Card className="max-w-4xl w-full bg-white shadow-md p-8 rounded-lg">
        <h1 className="text-2xl font-bold text-center">
          {isEditing ? 'Edit Information' : 'View Information'}
        </h1>
        <div className="space-y-4 mt-4">
          <div>
            <Label>Email</Label>
            <TextInput name="email" value={userInfo.email} disabled className="bg-gray-100" />
          </div>
          <div>
            <Label>Name</Label>
            <TextInput name="name" value={userInfo.name} onChange={handleChange} disabled={!isEditing} />
          </div>
          <div>
            <Label>Phone Number</Label>
            <TextInput name="phoneNumber" value={userInfo.phoneNumber} onChange={handleChange} disabled={!isEditing} />
          </div>
          <div>
            <Label>NID Number</Label>
            <TextInput name="nidNumber" value={userInfo.nidNumber} onChange={handleChange} disabled={!isEditing}/>
          </div>
          <div>
            <Label>Address</Label>
            <Textarea name="address" value={userInfo.address} onChange={handleChange} disabled={!isEditing} />
          </div>
          <div>
            <Label>Date of Birth</Label>
            <TextInput type="date" name="dateOfBirth" value={userInfo.dateOfBirth} onChange={handleChange} disabled={!isEditing} />
          </div>
          <div>
            <Label>Gender</Label>
            <Select name="gender" value={userInfo.gender} onChange={handleChange} disabled={!isEditing}>
              <option value="">Select Gender</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </Select>
          </div>
        </div>
        <div className="flex justify-between mt-6">
          <Button onClick={() => setIsEditing(!isEditing)} color="blue">
            {isEditing ? 'Cancel' : 'Edit'}
          </Button>
          {isEditing && (
            <Button onClick={handleSubmit} color="blue">
              Save
            </Button>
          )}
        </div>
      </Card>
    </div>
  );
}
