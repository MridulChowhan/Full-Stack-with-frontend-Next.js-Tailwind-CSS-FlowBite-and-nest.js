'use client';

import { useEffect, useState } from 'react';
import { Table, Button } from 'flowbite-react';
import { useRouter } from 'next/navigation';

export default function AppointmentListPage() {
  const [appointments, setAppointments] = useState([]);
  const [error, setError] = useState(null);
  const router = useRouter();


  const getUserIdFromToken = () => {
    const token = localStorage.getItem('authToken');
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1]));
      return payload.id; 
    } catch (error) {
      console.error('Error decoding token:', error);
      return null;
    }
  };


  useEffect(() => {
    const fetchAppointments = async () => {
      const userId = getUserIdFromToken();
      if (!userId) {
        router.push('/login');
        return;
      }

      try {
        const response = await fetch(`http://localhost:4000/appointment/patient/${userId}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('authToken')}`,
          },
        });

        if (!response.ok) {
          throw new Error(`Failed to fetch data: ${response.statusText}`);
        }

        const { data } = await response.json();
        setAppointments(data);
      } catch (error) {
        setError(error.message);
        console.error('Error fetching appointments:', error);
      }
    };

    fetchAppointments();
  }, [router]);

  const handleBack = () => {
    router.back();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-purple-700 flex items-center justify-center p-6">
      <div className="w-full max-w-7xl bg-white shadow-2xl rounded-2xl p-8">
        <h1 className="text-3xl font-extrabold text-center text-gray-800 mb-6">
          Your Appointments
        </h1>
        <p className="text-center text-gray-600 mb-8">
          View all your scheduled appointments below.
        </p>

        {error && (
          <div className="text-red-500 text-center mb-6">
            <p>Error: {error}</p>
          </div>
        )}

        <Table hoverable>
          <Table.Head>
            <Table.HeadCell>Doctor Name</Table.HeadCell>
            <Table.HeadCell>Doctor Specialization</Table.HeadCell>
            <Table.HeadCell>Appointment Date</Table.HeadCell>
            <Table.HeadCell>Reason for Visit</Table.HeadCell>
          </Table.Head>
          <Table.Body>
            {appointments.length > 0 ? (
              appointments.map((appointment) => (
                <Table.Row key={appointment.id}>
                  <Table.Cell>{appointment.doctorName}</Table.Cell>
                  <Table.Cell>{appointment.doctorSpecialization}</Table.Cell>
                  <Table.Cell>{new Date(appointment.appointmentDateTime).toLocaleString()}</Table.Cell>
                  <Table.Cell>{appointment.reasonForVisit}</Table.Cell>
                </Table.Row>
              ))
            ) : (
              <Table.Row>
                <Table.Cell colSpan={5} className="text-center">
                  No appointments found
                </Table.Cell>
              </Table.Row>
            )}
          </Table.Body>
        </Table>

        <div className="w-full max-w-6xl flex items-center justify-start mb-6">
          <Button
            onClick={handleBack}
            className="bg-blue-700 hover:bg-blue-800 text-white font-medium px-4 py-2 rounded-lg"
          >
            ← Back
          </Button>
        </div>
      </div>
    </div>
  );
}