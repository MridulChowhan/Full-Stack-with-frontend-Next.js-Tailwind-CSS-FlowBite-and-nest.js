'use client';

import { useState, useEffect } from 'react';
import { Table, Button } from 'flowbite-react';
import { useRouter } from 'next/navigation';

export default function ViewPrescriptionPage() {
  const [prescriptions, setPrescriptions] = useState([]);
  const [error, setError] = useState(null);
  const router = useRouter();

  // Function to extract user ID from the token
  const getUserIdFromToken = () => {
    const token = localStorage.getItem('authToken');
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1])); // Decode token payload
      return payload.id; // Assuming the user ID is stored in the token payload
    } catch (error) {
      console.error('Error decoding token:', error);
      return null;
    }
  };

  // Fetch prescriptions for the logged-in user
  useEffect(() => {
    const fetchPrescriptions = async () => {
      const userId = getUserIdFromToken();
      if (!userId) {
        router.push('/login');
        return;
      }
    
      try {
        const response = await fetch(`http://localhost:4000/pescription/patient/${userId}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('authToken')}`,
          },
        });
    
        if (!response.ok) {
          throw new Error(`Failed to fetch data: ${response.statusText}`);
        }
    
        const { data } = await response.json();
        setPrescriptions(data);
      } catch (error) {
        setError(error.message);
        console.error('Error fetching prescriptions:', error);
      }
    };

    fetchPrescriptions();
  }, [router]);

  const handleBack = () => {
    router.back();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-purple-500 to-purple-700 flex items-center justify-center p-6">
      <div className="w-full max-w-7xl bg-white shadow-2xl rounded-2xl p-8">
        <h1 className="text-3xl font-extrabold text-center text-gray-800 mb-6">
          Your Prescriptions
        </h1>
        <p className="text-center text-gray-600 mb-8">
          View all your medical prescriptions below.
        </p>

        {error && (
          <div className="text-red-500 text-center mb-6">
            <p>Error: {error}</p>
          </div>
        )}

        <Table hoverable>
          <Table.Head>
            <Table.HeadCell>#</Table.HeadCell>
            <Table.HeadCell>Patient ID</Table.HeadCell>
            <Table.HeadCell>Doctor Name</Table.HeadCell>
            <Table.HeadCell>Prescription Details</Table.HeadCell>
            <Table.HeadCell>Date</Table.HeadCell>
          </Table.Head>
          <Table.Body>
            {prescriptions.length > 0 ? (
              prescriptions.map((prescription, index) => (
                <Table.Row key={prescription.id}>
                  <Table.Cell className="font-medium">{index + 1}</Table.Cell>
                  <Table.Cell>{prescription.patientId}</Table.Cell>
                  <Table.Cell>{prescription.doctorName}</Table.Cell>
                  <Table.Cell className="text-gray-600">{prescription.prescriptionDetails}</Table.Cell>
                  <Table.Cell className="text-gray-500">{new Date(prescription.date).toLocaleString()}</Table.Cell>
                </Table.Row>
              ))
            ) : (
              <Table.Row>
                <Table.Cell colSpan={5} className="text-center">
                  No prescriptions found
                </Table.Cell>
              </Table.Row>
            )}
          </Table.Body>
        </Table>

        <div className="w-full max-w-6xl flex items-center justify-start mb-6">
          <Button
            onClick={handleBack}
            className="bg-blue-700 hover:bg-blue-800 text-white font-medium px-4 py-2 rounded-lg"
          >
            ← Back
          </Button>
        </div>
      </div>
    </div>
  );
}