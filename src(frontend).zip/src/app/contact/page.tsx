'use client';
import React from "react";
import Link from 'next/link';

export default function page() {
  return (
    <div>
      
      <nav className="bg-blue-600 py-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center px-6">
          <div className="text-white text-2xl font-bold">E-Health Care Services</div>
          <div className="flex space-x-6">
            <Link href="/" className="text-white hover:text-gray-300">Home</Link>
            <Link href="../services" className="text-white hover:text-gray-300">Services</Link>
            <Link href="../login" className="text-white hover:text-gray-300">Registration & Login</Link>
          </div>
        </div>
      </nav>
      <section className="bg-blue-600 py-24">
        <div className="container mx-auto text-center text-white">
          <h2 className="text-3xl font-semibold mb-8">Get In Touch</h2>
          <p className="text-lg mb-6">
            Have any questions? Feel free to reach out to us anytime.
          </p>
          <a href="mailto:chowhan652@gmail.com" className="bg-white text-blue-600 py-2 px-6 rounded-full text-lg hover:bg-gray-200 transition duration-300">
            Email Us
          </a>
        </div>
      </section>
    </div>
  );
}
