'use client';

import { useState, useEffect } from 'react';
import { Card, Label, TextInput, Button, Select, Alert } from 'flowbite-react';
import { useRouter } from 'next/navigation';

export default function PaymentCreationPage() {
  const [formData, setFormData] = useState({
    doctorId: '',
    doctorName: '',
    patientId: '',
    patientName: '',
    patientEmail: '',
    amount: '',
    paymentMethod: '',
    paymentDate: '',
  });

  const [successMessage, setSuccessMessage] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const router = useRouter();

  // Function to extract user ID and Email from the token
  const getUserDataFromToken = () => {
    const token = localStorage.getItem('authToken');
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1])); // Decode token payload
      return {
        id: payload.id, // Assuming user ID is stored in token
        email: payload.email, // Assuming email is stored in token
      };
    } catch (error) {
      console.error('Error decoding token:', error);
      return null;
    }
  };

  // Auto-fill patientId and patientEmail from token
  useEffect(() => {
    const userData = getUserDataFromToken();
    if (userData) {
      setFormData((prev) => ({
        ...prev,
        patientId: userData.id,
        patientEmail: userData.email,
      }));
    } else {
      router.push('/login');
    }
  }, [router]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSuccessMessage('');
    setErrorMessage('');

    try {
      const response = await fetch('http://localhost:4000/payment/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('authToken')}`,
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        setSuccessMessage('✅ Payment successfully created! Redirecting to Dashboard...');
        setTimeout(() => {
          router.push('/dashboard');
        }, 2000);
      } else {
        setErrorMessage('❌ Failed to create payment. Please try again.');
      }
    } catch (error) {
      console.error('Error creating payment:', error);
      setErrorMessage('⚠️ An error occurred. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-600 via-green-500 to-green-700 flex items-center justify-center p-6">
      <Card className="max-w-4xl w-full bg-white shadow-2xl rounded-2xl p-8">
        <h1 className="text-3xl font-extrabold text-center text-gray-800 mb-6">
          Create Payment
        </h1>
        <p className="text-center text-gray-600 mb-8">
          Fill out the form below to create a payment record.
        </p>

        {/* Success & Error Alerts */}
        {successMessage && <Alert color="success">{successMessage}</Alert>}
        {errorMessage && <Alert color="failure">{errorMessage}</Alert>}

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="doctorId" value="Doctor ID" className="mb-2 block font-bold" />
            <TextInput id="doctorId" name="doctorId" placeholder="Enter Doctor ID" type="number" required value={formData.doctorId} onChange={handleChange} />
          </div>
          <div>
            <Label htmlFor="doctorName" value="Doctor Name" className="mb-2 block font-bold" />
            <TextInput id="doctorName" name="doctorName" placeholder="Enter Doctor's Name" type="text" required value={formData.doctorName} onChange={handleChange} />
          </div>
          <div>
            <Label htmlFor="patientId" value="Patient ID" className="mb-2 block font-bold" />
            <TextInput id="patientId" name="patientId" type="number" value={formData.patientId} disabled />
          </div>
          <div>
            <Label htmlFor="patientName" value="Patient Name " className="mb-2 block font-bold" />
            <TextInput id="patientName" name="patientName" placeholder="Enter Patient's Name" type="text" required value={formData.patientName} onChange={handleChange} />
          </div>
          <div>
            <Label htmlFor="patientEmail" value="Patient Email" className="mb-2 block font-bold" />
            <TextInput id="patientEmail" name="patientEmail" type="email" value={formData.patientEmail} disabled />
          </div>
          <div>
            <Label htmlFor="amount" value="Amount" className="mb-2 block font-bold" />
            <TextInput id="amount" name="amount" placeholder="Enter Payment Amount" type="number" step="0.01" required value={formData.amount} onChange={handleChange} />
          </div>
          <div>
            <Label htmlFor="paymentMethod" value="Payment Method" className="mb-2 block font-bold" />
            <Select id="paymentMethod" name="paymentMethod" required value={formData.paymentMethod} onChange={handleChange}>
              <option value="" disabled>Select Payment Method</option>
              <option value="Credit Card">Credit Card</option>
              <option value="Bkash">Bkash</option>
              <option value="Nagad">Nagad</option>
              <option value="Rocket">Rocket</option>
            </Select>
          </div>
          <div>
            <Label htmlFor="paymentDate" value="Payment Date" className="mb-2 block font-bold" />
            <TextInput id="paymentDate" name="paymentDate" placeholder="Select Payment Date" type="date" required value={formData.paymentDate} onChange={handleChange} />
          </div>
          <div className="flex justify-between mt-6">
            <Button onClick={() => router.back()} className="bg-blue-700 hover:bg-blue-800 text-white font-medium px-4 py-2 rounded-lg">
              ← Back
            </Button>
            <Button type="submit" className="bg-blue-700 hover:bg-blue-800 text-white font-medium px-4 py-2 rounded-lg">
              Create Payment
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}
