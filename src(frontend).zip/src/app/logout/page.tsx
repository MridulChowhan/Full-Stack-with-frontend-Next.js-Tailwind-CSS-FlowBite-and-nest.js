'use client';

import { useRouter } from 'next/navigation';
import { Button, Card } from 'flowbite-react';

export default function LogoutPage() {
  const router = useRouter();

  const handleLogout = () => {
    // Remove token from localStorage
    localStorage.removeItem('authToken');
    console.log('User logged out');

    // Redirect to login page
    router.push('/login'); 
  };

  const handleCancel = () => {
    // Go back to the previous page
    router.back(); 
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-500 via-red-400 to-red-600 flex items-center justify-center p-6">
      <Card className="max-w-md w-full bg-white shadow-2xl rounded-2xl p-8">
        <h1 className="text-2xl font-bold text-center text-gray-800 mb-6">
          Are you sure you want to log out?
        </h1>
        <div className="flex justify-between mt-4">
          <Button
            onClick={handleCancel}
            className="bg-gray-500 hover:bg-gray-600 text-white font-medium px-4 py-2 rounded-lg w-40"
          >
            Cancel
          </Button>
          <Button
            onClick={handleLogout}
            className="bg-red-700 hover:bg-red-800 text-white font-medium px-4 py-2 rounded-lg w-40"
          >
            Log Out
          </Button>
        </div>
      </Card>
    </div>
  );
}
