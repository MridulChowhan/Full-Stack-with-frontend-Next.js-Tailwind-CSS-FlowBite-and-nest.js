'use client';

import { useState, useEffect } from 'react';
import { Card, Label, TextInput, Button, Textarea, Select } from 'flowbite-react';
import { useRouter } from 'next/navigation';

export default function AppointmentBookingPage() {
  const [formData, setFormData] = useState({
    doctorId: '',
    doctorName: '',
    doctorSpecialization: '',
    appointmentDateTime: '',
    patientId: '',
    reasonForVisit: '',
  });

  const [appointments, setAppointments] = useState([]);
  const router = useRouter();

  // Function to extract user ID from the token
  const getUserIdFromToken = () => {
    const token = localStorage.getItem('authToken');
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1])); // Decode token payload
      return payload.id; // Assuming the user ID is stored in the token payload
    } catch (error) {
      console.error('Error decoding token:', error);
      return null;
    }
  };

  // Fetch logged-in user's appointments
  useEffect(() => {
    const fetchAppointments = async () => {
      const userId = getUserIdFromToken();
      if (!userId) {
        router.push('/login');
        return;
      }

      try {
        const response = await fetch(`http://localhost:4000/appointment/patient/${userId}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('authToken')}`,
          },
        });

        if (!response.ok) {
          throw new Error('Failed to fetch appointments');
        }

        const { data } = await response.json();
        setAppointments(data);
      } catch (error) {
        console.error('Error fetching appointments:', error);
      }
    };

    fetchAppointments();
  }, [router]);

  // Automatically populate patientId with logged-in user's ID
  useEffect(() => {
    const userId = getUserIdFromToken();
    if (userId) {
      setFormData((prev) => ({ ...prev, patientId: userId }));
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const userId = getUserIdFromToken();
    if (!userId) {
      router.push('/login');
      return;
    }

    try {
      const response = await fetch('http://localhost:4000/appointment/appoint', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('authToken')}`,
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error('Failed to book appointment');
      }

      const result = await response.json();
      console.log('Appointment Booked:', result);
      alert('Appointment booked successfully!');
      router.refresh(); 
    } catch (error) {
      console.error('Error booking appointment:', error);
      alert('Failed to book appointment. Please try again.');
    }
  };

  const handleBack = () => {
    router.back();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-blue-500 to-blue-700 flex items-center justify-center p-6">
      <Card className="max-w-4xl w-full bg-white shadow-2xl rounded-2xl p-8">
        <h1 className="text-3xl font-extrabold text-center text-gray-800 mb-6">
          Book Your Appointment
        </h1>
        <p className="text-center text-gray-600 mb-8">
          Fill out the form below to schedule your appointment with one of our specialists.
        </p>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="doctorId" value="Doctor ID" className="mb-2 block font-bold" />
            <TextInput
              id="doctorId"
              name="doctorId"
              placeholder="Enter Doctor ID"
              type="number"
              required
              value={formData.doctorId}
              onChange={handleChange}
            />
          </div>

          <div>
            <Label htmlFor="doctorName" value="Doctor Name" className="mb-2 block font-bold" />
            <TextInput
              id="doctorName"
              name="doctorName"
              placeholder="Enter Doctor's Name"
              type="text"
              required
              value={formData.doctorName}
              onChange={handleChange}
            />
          </div>

          <div>
            <Label htmlFor="doctorSpecialization" value="Doctor Specialization" className="mb-2 block font-bold" />
            <Select
              id="doctorSpecialization"
              name="doctorSpecialization"
              required
              value={formData.doctorSpecialization}
              onChange={handleChange}
            >
              <option value="" disabled>
                Select Specialization
              </option>
              <option value="Cardiologist">Cardiologist</option>
              <option value="Neurologist">Neurologist</option>
              <option value="Dermatologist">Dermatologist</option>
              <option value="General Physician">General Physician</option>
              <option value="Orthopedic">Orthopedic</option>
            </Select>
          </div>

          <div>
            <Label htmlFor="appointmentDateTime" value="Appointment Date & Time" className="mb-2 block font-bold" />
            <TextInput
              id="appointmentDateTime"
              name="appointmentDateTime"
              placeholder="Select Appointment Date and Time"
              type="datetime-local"
              required
              value={formData.appointmentDateTime}
              onChange={handleChange}
            />
          </div>

          <div>
            <Label htmlFor="patientId" value="Patient ID" className="mb-2 block font-bold" />
            <TextInput
              id="patientId"
              name="patientId"
              placeholder="Enter Patient ID"
              type="number"
              required
              value={formData.patientId}
              onChange={handleChange}
              disabled 
            />
          </div>

          <div>
            <Label htmlFor="reasonForVisit" value="Reason for Visit" className="mb-2 block font-bold" />
            <Textarea
              id="reasonForVisit"
              name="reasonForVisit"
              placeholder="Describe the reason for your visit..."
              required
              value={formData.reasonForVisit}
              onChange={handleChange}
            />
          </div>

          <div className="w-full max-w-6xl flex justify-between mb-6">
            <Button
              onClick={handleBack}
              className="bg-blue-700 hover:bg-blue-800 text-white font-medium px-4 py-2 rounded-lg"
            >
              ← Back
            </Button>
            <Button
              type="submit"
              className="bg-blue-700 hover:bg-blue-800 text-white font-medium px-4 py-2 rounded-lg"
            >
              Book Appointment
            </Button>
          </div>
        </form>
       
      </Card>
    </div>
  );
}