'use client';

import { useState, useEffect } from 'react';
import { Card, Label, TextInput, Button, Textarea } from 'flowbite-react';
import { useRouter } from 'next/navigation';

export default function CreateTestRecordPage() {
  const [formData, setFormData] = useState({
    patientId: '',
    patientName: '',
    testName: '',
    testDatetime: '',
  });

  const router = useRouter();

  // Function to extract user ID from the token
  const getUserIdFromToken = () => {
    const token = localStorage.getItem('authToken');
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1])); // Decode token payload
      return payload.id; // Assuming the user ID is stored in the token payload
    } catch (error) {
      console.error('Error decoding token:', error);
      return null;
    }
  };

  // Automatically populate patientId with logged-in user's ID
  useEffect(() => {
    const userId = getUserIdFromToken();
    if (userId) {
      setFormData((prev) => ({ ...prev, patientId: userId }));
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
  
    const userId = getUserIdFromToken();
    if (!userId) {
      router.push('/login');
      return;
    }
  
    try {
      const response = await fetch('http://localhost:4000/records/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${localStorage.getItem('authToken')}`,
        },
        body: JSON.stringify(formData),
      });
  
      if (!response.ok) {
        throw new Error('Failed to create test record');
      }
  
      const result = await response.json();
      console.log('Test Record Created:', result);
      alert('Test record created successfully!');
      router.push('../healthrecord'); 
    } catch (error) {
      console.error('Error creating test record:', error);
      alert('Failed to create test record. Please try again.');
    }
  };

  const handleBack = () => {
    router.back();
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-blue-500 to-blue-700 flex items-center justify-center p-6">
      <Card className="max-w-4xl w-full bg-white shadow-2xl rounded-2xl p-8">
        <h1 className="text-3xl font-extrabold text-center text-gray-800 mb-6">
          Create Test Record
        </h1>
        <p className="text-center text-gray-600 mb-8">
          Fill out the form below to create a new test record.
        </p>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="patientId" value="Patient ID" className="mb-2 block font-bold" />
            <TextInput
              id="patientId"
              name="patientId"
              placeholder="Enter Patient ID"
              type="number"
              required
              value={formData.patientId}
              onChange={handleChange}
              disabled 
            />
          </div>

          <div>
            <Label htmlFor="patientName" value="Patient Name" className="mb-2 block font-bold" />
            <TextInput
              id="patientName"
              name="patientName"
              placeholder="Enter Patient Name"
              type="text"
              required
              value={formData.patientName}
              onChange={handleChange}
            />
          </div>

          <div>
            <Label htmlFor="testName" value="Test Name" className="mb-2 block font-bold" />
            <TextInput
              id="testName"
              name="testName"
              placeholder="Enter Test Name"
              type="text"
              required
              value={formData.testName}
              onChange={handleChange}
            />
          </div>

          <div>
            <Label htmlFor="testDatetime" value="Test Date & Time" className="mb-2 block font-bold" />
            <TextInput
              id="testDatetime"
              name="testDatetime"
              placeholder="Select Test Date and Time"
              type="datetime-local"
              required
              value={formData.testDatetime}
              onChange={handleChange}
            />
          </div>

          <div className="w-full max-w-6xl flex justify-between mb-6">
            <Button
              onClick={handleBack}
              className="bg-blue-700 hover:bg-blue-800 text-white font-medium px-4 py-2 rounded-lg"
            >
              ← Back
            </Button>
            <Button
              type="submit"
              className="bg-blue-700 hover:bg-blue-800 text-white font-medium px-4 py-2 rounded-lg"
            >
              Create Record
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
}