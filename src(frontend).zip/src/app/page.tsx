'use client';
import React from "react";

export default function page() {
  return (
    <div>
      <nav className="bg-blue-600 py-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center px-6">
          <div className="text-white text-2xl font-bold">E-Health Care Services</div>
          <div className="flex space-x-6">
            <a href="./login" className="text-white hover:text-gray-300">Login Patient</a>
            <a href="./services" className="text-white hover:text-gray-300">Services</a>
            <a href="./contact" className="text-white hover:text-gray-300">Contact</a>
          </div>
        </div>
      </nav>
      <section className="bg-[url('/service4.svg')]">
        <br></br>
        <div className="container mx-auto text-center">
          <h1 className="text-5xl font-bold text-red-600 mb-4">Welcome to E-Health Care Services</h1>
        </div>
        <br></br>
        <section id="services" className="py-24">
          <div className="container mx-auto text-center">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
              <div className="bg-white shadow-lg rounded-lg p-6">
                <h3 className="text-xl font-semibold text-blue-600 mb-4">Telemedicine</h3>
                <p className="text-gray-600 mb-4">
                  Consult with doctors from the comfort of your home. Fast and easy online consultations.
                </p>
              </div>
              <div className="bg-white shadow-lg rounded-lg p-6">
                <h3 className="text-xl font-semibold text-blue-600 mb-4">Emergency Services</h3>
                <p className="text-gray-600 mb-4">
                  Our team is always ready to assist with any medical emergencies. Available 24/7.
                </p>
              </div>
              <div className="bg-white shadow-lg rounded-lg p-6">
                <h3 className="text-xl font-semibold text-blue-600 mb-4">Health Checkups</h3>
                <p className="text-gray-600 mb-4">
                  Regular checkups to monitor your health and catch any potential issues early.
                </p>
              </div>
            </div>
          </div>
        </section>
        <section id="contact" className="bg-blue-600 py-24">
          <div className="container mx-auto text-center text-white">
            <h2 className="text-3xl font-semibold mb-8">Get In Touch</h2>
            <p className="text-lg mb-6">
              Have any questions? Feel free to reach out to us anytime.
            </p>
            <a href="mailto:chowhan652@gmail.com" className="bg-white text-blue-600 py-2 px-6 rounded-full text-lg hover:bg-gray-200 transition duration-300">
              Email Us
            </a>
          </div>
        </section>
      </section>
    </div>
  );
}
