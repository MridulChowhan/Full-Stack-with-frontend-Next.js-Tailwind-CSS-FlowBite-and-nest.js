'use client';

import { useEffect, useState } from 'react';
import { Table, Button, Spinner, Alert } from 'flowbite-react';
import { useRouter } from 'next/navigation';

export default function ViewAllRecordsPage() {
  const [records, setRecords] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const router = useRouter();


  const getUserIdFromToken = () => {
    const token = localStorage.getItem('authToken');
    if (!token) return null;

    try {
      const payload = JSON.parse(atob(token.split('.')[1])); 
      return payload.id; 
    } catch (error) {
      console.error('Error decoding token:', error);
      return null;
    }
  };

  useEffect(() => {
    async function fetchRecords() {
      const userId = getUserIdFromToken();
      if (!userId) {
        router.push('/login'); 
        return;
      }

      try {
        const response = await fetch(`http://localhost:4000/records/all?userId=${userId}`, {
          headers: {
            Authorization: `Bearer ${localStorage.getItem('authToken')}`,
          },
        });
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || 'Failed to fetch records');
        }
        const data = await response.json();
        setRecords(data);
      } catch (error) {
        console.error('Error fetching records:', error);
        setError(error.message);
      } finally {
        setLoading(false);
      }
    }

    fetchRecords();
  }, [router]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Spinner size="xl" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Alert color="failure">
          {error}
        </Alert>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center p-6">
      <header className="mb-8 text-center">
        <h1 className="text-4xl font-bold text-blue-700 mb-4">Test Records</h1>
        <p className="text-gray-600">
          Below is the list of all test records for your account.
        </p>
      </header>

      <div className="w-full max-w-6xl bg-white shadow-md rounded-lg overflow-hidden mb-6">
        <Table hoverable={true} className="w-full">
          <Table.Head className="bg-gray-100 text-black">
            <Table.HeadCell>#</Table.HeadCell>
            <Table.HeadCell>Patient ID</Table.HeadCell>
            <Table.HeadCell>Patient Name</Table.HeadCell>
            <Table.HeadCell>Test Name</Table.HeadCell>
            <Table.HeadCell>Test Date & Time</Table.HeadCell>
            <Table.HeadCell>Created At</Table.HeadCell>
          </Table.Head>
          <Table.Body className="divide-y">
            {records.length > 0 ? (
              records.map((record, index) => (
                <Table.Row
                  key={record.id}
                  className="hover:bg-blue-50 text-black transition duration-300 ease-in-out"
                >
                  <Table.Cell className="font-medium">{index + 1}</Table.Cell>
                  <Table.Cell>{record.patientId}</Table.Cell>
                  <Table.Cell>{record.patientName}</Table.Cell>
                  <Table.Cell>{record.testName}</Table.Cell>
                  <Table.Cell>{new Date(record.testDatetime).toLocaleString()}</Table.Cell>
                  <Table.Cell>{new Date(record.createdAt).toLocaleString()}</Table.Cell>
                </Table.Row>
              ))
            ) : (
              <Table.Row>
                <Table.Cell colSpan="6" className="text-center text-gray-500 py-6">
                  No records available.
                </Table.Cell>
              </Table.Row>
            )}
          </Table.Body>
        </Table>
      </div>

      <div className="w-full max-w-6xl flex justify-start mt-auto">
        <Button
          onClick={() => router.back()}
          className="bg-blue-700 hover:bg-blue-800 text-white font-medium px-4 py-2 rounded-lg"
        >
          ← Back
        </Button>
      </div>
    </div>
  );
}