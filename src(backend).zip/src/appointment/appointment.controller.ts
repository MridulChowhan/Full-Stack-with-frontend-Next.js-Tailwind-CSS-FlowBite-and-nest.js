import {
  Controller,
  Post,
  Body,
  HttpException,
  HttpStatus,
  Delete,
  Param,
  Get,
  Patch,
  UseGuards,
} from '@nestjs/common';
import { AppointmentService } from './appointment.service';
import { Appointment } from './appointment.entity';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { AuthGuard } from '@nestjs/passport';

@Controller('appointment')
@UseGuards(JwtAuthGuard) 
export class AppointmentController {
  constructor(private readonly appointmentService: AppointmentService) {}

  @Post('appoint')
  async appoint(@Body() patientData: Partial<Appointment>) {
    try {
      const appointmentPatient =
        await this.appointmentService.appoint(patientData);
      return {
        message: 'Appointment Confirmed',
        data: appointmentPatient,
      };
    } catch (error) {
      console.error('Failed to confirm appointment', error);
      throw new HttpException(
        'Appointment confirmation failed',
        HttpStatus.BAD_REQUEST,
      );
    }
  }
  @UseGuards(JwtAuthGuard) 
  @Get('patient/:patientId')
  async getAppointmentsByPatientId(@Param('patientId') patientId: string) {
    try {
      const appointments =
        await this.appointmentService.getAppointmentsByPatientId(
          parseInt(patientId, 10),
        );
      return {
        message: 'Appointments retrieved successfully',
        data: appointments,
      };
    } catch (error) {
      console.error('Failed to retrieve appointments by patient ID', error);
      throw new HttpException(
        'Failed to retrieve appointments',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
  @Delete(':id')
  async deleteAppointment(@Param('id') id: string) {
    try {
      const result = await this.appointmentService.deleteAppointment(id);
      if (result.affected === 0) {
        throw new HttpException('Appointment not found', HttpStatus.NOT_FOUND);
      }
      return {
        message: 'Appointment deleted successfully',
      };
    } catch (error) {
      console.error('Failed to delete appointment', error);
      throw new HttpException(
        'Failed to delete appointment',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Get(':id')
  async getAppointmentById(@Param('id') id: string) {
    try {
      const appointment = await this.appointmentService.getAppointmentById(id);
      if (!appointment) {
        throw new HttpException('Appointment not found', HttpStatus.NOT_FOUND);
      }
      return {
        message: 'Appointment retrieved successfully',
        data: appointment,
      };
    } catch (error) {
      console.error('Failed to retrieve appointment by ID', error);
      throw new HttpException(
        'Failed to retrieve appointment',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Get()
  async getAllAppointments() {
    try {
      const appointments = await this.appointmentService.getAllAppointments();
      return {
        message: 'Appointments retrieved successfully',
        data: appointments,
      };
    } catch (error) {
      console.error('Failed to retrieve all appointments', error);
      throw new HttpException(
        'Failed to retrieve appointments',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
  @UseGuards(AuthGuard('jwt'))


  @Patch(':id')
  async updateAppointment(
    @Param('id') id: string,
    @Body() updateData: Partial<Appointment>,
  ) {
    try {
      const updatedAppointment =
        await this.appointmentService.updateAppointment(id, updateData);
      if (!updatedAppointment) {
        throw new HttpException('Appointment not found', HttpStatus.NOT_FOUND);
      }
      return {
        message: 'Appointment updated successfully',
        data: updatedAppointment,
      };
    } catch (error) {
      console.error('Failed to update appointment', error);
      throw new HttpException(
        'Failed to update appointment',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
