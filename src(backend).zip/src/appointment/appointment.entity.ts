import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity()
export class Appointment {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ type: 'int' })
  doctorId: number;

  @Column({ type: 'varchar', length: 100 })
  doctorName: string;

  @Column({ type: 'varchar', length: 100 })
  doctorSpecialization: string;

  @Column({ type: 'timestamp' })
  appointmentDateTime: Date;

  @Column({ type: 'int' })
  patientId: number;

  @Column({ type: 'text' })
  reasonForVisit: string;
}
