import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { PescriptionService } from './pescription.service';
import { PescriptionController } from './pescription.controller';
import { Prescription } from './pescription.entity';
import { JwtModule } from '@nestjs/jwt';

@Module({
  imports: [
    TypeOrmModule.forFeature([Prescription]), 
    JwtModule.register({
      secret: 'your-secret-key',
      signOptions: { expiresIn: '1h' },
    }),
  ],
  controllers: [PescriptionController],
  providers: [PescriptionService],
})
export class PescriptionModule {}
