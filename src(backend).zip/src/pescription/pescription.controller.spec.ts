import { Test, TestingModule } from '@nestjs/testing';
import { PescriptionController } from './pescription.controller';

describe('PescriptionController', () => {
  let controller: PescriptionController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [PescriptionController],
    }).compile();

    controller = module.get<PescriptionController>(PescriptionController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
