import {
  Controller,
  Post,
  Body,
  Get,
  Param,
  HttpException,
  HttpStatus,
  UseGuards,
  Query,
} from '@nestjs/common';
import { PescriptionService } from './pescription.service';
import { Prescription } from './pescription.entity';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@Controller('pescription')
@UseGuards(JwtAuthGuard)
export class PescriptionController {
  constructor(private readonly pescriptionService: PescriptionService) {}

  @Post('create')
  async createPrescription(@Body() patientData: Partial<Prescription>) {
    try {
      const pescriptionPatient =
        await this.pescriptionService.createPrescription(patientData);
      return {
        message: 'Prescription created successfully',
        data: pescriptionPatient,
      };
    } catch (error) {
      console.error('Failed to create prescription', error);
      throw new HttpException(
        'Prescription creation failed',
        HttpStatus.BAD_REQUEST,
      );
    }
  }
  @Get('patient/:patientId')
  async getPrescriptionsByPatientId(@Param('patientId') patientId: string) {
    try {
      const prescriptions =
        await this.pescriptionService.getPrescriptionsByPatientId(patientId);
      return {
        message: 'Prescriptions retrieved successfully',
        data: prescriptions,
      };
    } catch (error) {
      console.error('Failed to retrieve prescriptions by patient ID', error);
      throw new HttpException(
        'Failed to retrieve prescriptions',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
  @Get(':id')
  async getPrescriptionById(@Param('id') id: string) {
    try {
      const prescription =
        await this.pescriptionService.getPrescriptionById(id);
      if (!prescription) {
        throw new HttpException('Prescription not found', HttpStatus.NOT_FOUND);
      }
      return {
        message: 'Prescription retrieved successfully',
        data: prescription,
      };
    } catch (error) {
      console.error('Failed to retrieve prescription by ID', error);
      throw new HttpException(
        'Failed to retrieve prescription',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Get()
  async getAllPrescriptions(@Query('userId') userId: string) {
    try {
      const prescriptions =
        await this.pescriptionService.getAllPrescriptions(userId);
      return {
        message: 'Prescriptions retrieved successfully',
        data: prescriptions,
      };
    } catch (error) {
      console.error('Failed to retrieve all prescriptions', error);
      throw new HttpException(
        'Failed to retrieve prescriptions',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
