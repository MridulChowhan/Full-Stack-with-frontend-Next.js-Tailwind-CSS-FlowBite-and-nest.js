import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Prescription } from './pescription.entity';

@Injectable()
export class PescriptionService {
  constructor(
    @InjectRepository(Prescription)
    private readonly pescrptionRepo: Repository<Prescription>,
  ) {}

  async createPrescription(
    patientData: Partial<Prescription>,
  ): Promise<Prescription> {
    const newPrescription = this.pescrptionRepo.create(patientData);
    return this.pescrptionRepo.save(newPrescription);
  }
  async getPrescriptionsByPatientId(
    patientId: string,
  ): Promise<Prescription[]> {
    const numericPatientId = Number(patientId);
    if (isNaN(numericPatientId)) {
      return [];
    }
    return this.pescrptionRepo.find({ where: { patientId: numericPatientId } });
  }
  async getPrescriptionById(id: string): Promise<Prescription | null> {
    const numericId = Number(id);
    if (isNaN(numericId)) {
      return null;
    }
    return this.pescrptionRepo.findOne({ where: { id: numericId } });
  }

  async getAllPrescriptions(userId: string): Promise<Prescription[]> {
    return this.pescrptionRepo.find({ where: { patientId: Number(userId) } });
  }
}
