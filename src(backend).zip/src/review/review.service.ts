import { Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository, DeleteResult } from 'typeorm';
import { Review } from './review.entity';

@Injectable()
export class ReviewService {
  constructor(
    @InjectRepository(Review)
    private readonly reviewRepo: Repository<Review>,
  ) {}

  async create(reviewData: any) {
    const review = this.reviewRepo.create(reviewData);
    return this.reviewRepo.save(review);
  }

  async getReviewsByDoctorId(doctorId: number): Promise<Review[]> {
    return this.reviewRepo.find({ where: { doctorId } });
  }

  async deleteReview(id: string): Promise<DeleteResult> {
    return this.reviewRepo.delete(id);
  }

  async getReviewById(id: string): Promise<Review | null> {
    return this.reviewRepo.findOne({ where: { id: parseInt(id, 10) } });
  }

  async getAllReviews(): Promise<Review[]> {
    return this.reviewRepo.find();
  }

  async findByDoctorId(doctorId: number) {
    return this.reviewRepo.find({ where: { doctorId } });
  }
  async updateReview(
    id: string,
    updateData: Partial<Review>,
  ): Promise<Review | null> {
    await this.reviewRepo.update(id, updateData);
    return this.reviewRepo.findOne({ where: { id: parseInt(id, 10) } });
  }
}
