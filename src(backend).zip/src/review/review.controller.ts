import { 
  Controller,
  Post,
  Body,
  Get,
  Param,
  HttpException,
  HttpStatus,
  UseGuards,
  Req,
  Delete,
  Patch,
  Request,
} from '@nestjs/common';
import { ReviewService } from './review.service';
import { Review } from './review.entity';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { AuthGuard } from '@nestjs/passport';

@Controller('review')
@UseGuards(JwtAuthGuard)
export class ReviewController {
  constructor(private readonly reviewService: ReviewService) {}

  @Post('create')
  @UseGuards(AuthGuard()) // Ensure the user is authenticated
  async createReview(@Body() reviewData: any, @Request() req) {
    const patientId = req.user.id; // Get patient ID from the authenticated user

    if (!patientId) {
      throw new Error('Patient ID is missing from the authenticated user');
    }

    return this.reviewService.create({
      ...reviewData,
      patientId, // Attach the patient ID
    });
  }

  @Get('doctor/:doctorId')
  async getReviewsByDoctorId(@Param('doctorId') doctorId: string) {
    try {
      const reviews = await this.reviewService.getReviewsByDoctorId(
        parseInt(doctorId, 10),
      );
      return {
        message: 'Reviews retrieved successfully',
        data: reviews,
      };
    } catch (error) {
      console.error('Failed to retrieve reviews by doctor ID', error);
      throw new HttpException(
        'Failed to retrieve reviews',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Delete(':id')
  async deleteReview(@Param('id') id: string) {
    try {
      const result = await this.reviewService.deleteReview(id);
      if (result.affected === 0) {
        throw new HttpException('Review not found', HttpStatus.NOT_FOUND);
      }
      return {
        message: 'Review deleted successfully',
      };
    } catch (error) {
      console.error('Failed to delete review', error);
      throw new HttpException(
        'Failed to delete review',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Get(':id')
  async getReviewById(@Param('id') id: string) {
    try {
      const review = await this.reviewService.getReviewById(id);
      if (!review) {
        throw new HttpException('Review not found', HttpStatus.NOT_FOUND);
      }
      return {
        message: 'Review retrieved successfully',
        data: review,
      };
    } catch (error) {
      console.error('Failed to retrieve review by ID', error);
      throw new HttpException(
        'Failed to retrieve review',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Get()
  async getAllReviews() {
    try {
      const reviews = await this.reviewService.getAllReviews();
      return {
        message: 'Reviews retrieved successfully',
        data: reviews,
      };
    } catch (error) {
      console.error('Failed to retrieve all reviews', error);
      throw new HttpException(
        'Failed to retrieve reviews',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  @Patch(':id')
  async updateReview(
    @Param('id') id: string,
    @Body() updateData: Partial<Review>,
  ) {
    try {
      const updatedReview = await this.reviewService.updateReview(
        id,
        updateData,
      );
      if (!updatedReview) {
        throw new HttpException('Review not found', HttpStatus.NOT_FOUND);
      }
      return {
        message: 'Review updated successfully',
        data: updatedReview,
      };
    } catch (error) {
      console.error('Failed to update review', error);
      throw new HttpException(
        'Failed to update review',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}


