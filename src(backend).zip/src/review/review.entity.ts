import { Entity, PrimaryGeneratedColumn, Column } from 'typeorm';

@Entity() 
export class Review {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  doctorId: number;

  @Column({ length: 100 })
  doctorName: string;

  @Column()
  patientId: number;

  @Column({ length: 100 })
  patientName: string;

  @Column({ type: 'text', nullable: true })
  comments: string;

  @Column({ type: 'int', nullable: true }) // Add rating field
  rating: number;

  @Column({ type: 'timestamp', default: () => 'CURRENT_TIMESTAMP' })
  createdAt: Date;
}

