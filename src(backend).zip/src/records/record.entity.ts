import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
} from 'typeorm';

@Entity() 
export class Records {
  @PrimaryGeneratedColumn()
  id: number; 

  @Column({ type: 'int' })
  patientId: number; 

  @Column({ type: 'varchar', length: 100 })
  patientName: string; 

  @Column({ type: 'varchar', length: 100 })
  testName: string; 

  @Column({ type: 'timestamp' })
  testDatetime: Date; 

  @CreateDateColumn({ type: 'timestamp' })
  createdAt: Date; 
}
