import {
  Controller,
  Post,
  Body,
  HttpException,
  HttpStatus,
  Query,
  Get,
  UseGuards,
} from '@nestjs/common';
import { RecordsService } from './records.service';
import { Records } from './record.entity';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@Controller('records')
@UseGuards(JwtAuthGuard)
export class RecordsController {
  constructor(private readonly recordsService: RecordsService) {}

  @Post('create')
  async create(@Body() recordData: Partial<Records>) {
    try {
      const createdRecord = await this.recordsService.createRecord(recordData);
      return {
        message: 'Record created successfully',
        data: createdRecord,
      };
    } catch (error) {
      console.error('Record Creation Error:', error);
      throw new HttpException(
        'Failed to create record',
        HttpStatus.BAD_REQUEST,
      );
    }
  }
  @Get('all')
  async getRecords(@Query('userId') userId: string) {
    console.log('Fetching records for userId:', userId); // Log the userId
    try {
      const records = await this.recordsService.getRecordsByUserId(userId);
      return records;
    } catch (error) {
      console.error('Error fetching records:', error);
      throw new HttpException(
        'Failed to fetch records',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
