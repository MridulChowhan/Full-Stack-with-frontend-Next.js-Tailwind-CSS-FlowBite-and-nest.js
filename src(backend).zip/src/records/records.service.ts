import { HttpException, HttpStatus, Injectable } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Records } from './record.entity';

@Injectable()
export class RecordsService {
  constructor(
    @InjectRepository(Records)
    private readonly recordsRepo: Repository<Records>,
  ) {}

  async createRecord(recordData: Partial<Records>): Promise<Records> {
    const newRecord = this.recordsRepo.create(recordData);
    return await this.recordsRepo.save(newRecord);
  }
  async getRecordsByUserId(userId: string): Promise<Records[]> {
    const patientId = parseInt(userId, 10);
    if (isNaN(patientId)) {
      throw new HttpException('Invalid user ID', HttpStatus.BAD_REQUEST);
    }
    return await this.recordsRepo.find({ where: { patientId } });
  }
}

