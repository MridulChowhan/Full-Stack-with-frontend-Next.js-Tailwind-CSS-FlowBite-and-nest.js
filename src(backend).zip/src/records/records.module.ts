import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RecordsService } from './records.service';
import { RecordsController } from './records.controller';
import { Records } from './record.entity'; 
import { JwtModule } from '@nestjs/jwt';

@Module({
  imports: [
    TypeOrmModule.forFeature([Records]),
    JwtModule.register({
       secret: 'your-secret-key',
       signOptions: { expiresIn: '1h' },
     }),
   ],
  providers: [RecordsService],
  controllers: [RecordsController],
  exports: [RecordsService], 
})
export class RecordsModule {}
