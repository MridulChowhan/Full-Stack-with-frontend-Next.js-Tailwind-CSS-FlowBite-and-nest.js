import {
  Controller,
  Post,
  Body,
  Get,
  Param,
  HttpException,
  HttpStatus,
  Request,
  UseGuards,
} from '@nestjs/common';
import { PaymentService } from './payment.service';
import { Payment } from './payment.entity';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

@Controller('payment')
@UseGuards(JwtAuthGuard) 
export class PaymentController {
  constructor(private readonly paymentService: PaymentService) {}

  @Post('create')
  async createPayment(@Body() paymentData: Partial<Payment>) {
    try {
      const payment = await this.paymentService.createPayment(paymentData);
      return {
        message: 'Payment created successfully and email sent.',
        data: payment,
      };
    } catch (error) {
      console.error('Failed to create payment:', error.message);
      throw new HttpException(
        'Failed to create payment',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }


  @Get(':id')
  async getPaymentById(@Param('id') id: string) {
    try {
      const payment = await this.paymentService.getPaymentById(id);
      if (!payment) {
        throw new HttpException('Payment not found', HttpStatus.NOT_FOUND);
      }
      return { message: 'Payment retrieved successfully', data: payment };
    } catch (error) {
      console.error('Failed to retrieve payment:', error.message);
      throw new HttpException(
        'Failed to retrieve payment',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
  @UseGuards(JwtAuthGuard) // Ensure this route requires authentication
  @Get()
  async getUserPayments(@Request() req) {
    console.log('Authenticated User:', req.user); 
    if (!req.user) {
      throw new Error('User is not authenticated');
    }
    const userId = req.user.id; 
    return this.paymentService.getPaymentsByUserId(userId);
  }

  @Get()
  async getAllPayments() {
    try {
      const payments = await this.paymentService.getAllPayments();
      return { message: 'Payments retrieved successfully', data: payments };
    } catch (error) {
      console.error('Failed to retrieve payments:', error.message);
      throw new HttpException(
        'Failed to retrieve payments',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
}
