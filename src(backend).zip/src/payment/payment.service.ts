import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Payment } from './payment.entity';
import * as nodemailer from 'nodemailer';
import * as pdfMake from 'pdfmake/build/pdfmake';
import * as pdfFonts from 'pdfmake/build/vfs_fonts';


(pdfMake as any).vfs = (pdfFonts as any).vfs;



@Injectable()
export class PaymentService {
  constructor(
    @InjectRepository(Payment)
    private readonly paymentRepo: Repository<Payment>,
  ) {}

  async createPayment(paymentData: Partial<Payment>): Promise<Payment> {
    try {
      const newPayment = this.paymentRepo.create(paymentData);
      const savedPayment = await this.paymentRepo.save(newPayment);
      const pdfSlip = await this.generatePaymentSlip(savedPayment);
      await this.sendPaymentSlip(savedPayment.patientEmail, pdfSlip);
      return savedPayment;
    } catch (error) {
      console.error('Failed to create payment:', error.message);
      throw new HttpException(
        'Failed to create payment',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }

  async getPaymentById(id: string): Promise<Payment | null> {
    const numericId = Number(id);
    if (isNaN(numericId)) {
      return null;
    }
    return this.paymentRepo.findOne({ where: { id: numericId } });
  }


  private async generatePaymentSlip(payment: Payment): Promise<string> {
    const docDefinition = {
      content: [
        { text: 'Payment Receipt', style: 'header' },
        { text: `Payment ID: ${payment.id}`, style: 'subheader' },
        {
          text: `Doctor: ${payment.doctorName} (ID: ${payment.doctorId})`,
          style: 'paragraph',
        },
        {
          text: `Patient: ${payment.patientName} (ID: ${payment.patientId})`,
          style: 'paragraph',
        },
        { text: `Amount: $${payment.amount}`, style: 'paragraph' },
        {
          text: `Payment Method: ${payment.paymentMethod || 'Not Specified'}`,
          style: 'paragraph',
        },
        { text: `Date: ${payment.paymentDate}`, style: 'paragraph' },
      ],
      styles: {
        header: { fontSize: 18, bold: true, alignment: 'center' as const },
        subheader: {
          fontSize: 14,
          bold: true,
          margin: [0, 10] as [number, number],
        },
        paragraph: { fontSize: 12, margin: [0, 5] as [number, number] },
      },
    };

    const pdfDoc = pdfMake.createPdf(docDefinition);
    return new Promise<string>((resolve) => {
      pdfDoc.getBase64((data: string) => {
        resolve(data);
      });
    });
  }

  private async sendPaymentSlip(email: string, pdfSlip: string): Promise<void> {
    const transporter = nodemailer.createTransport({
      service: 'gmail',
      auth: {
        user: 's3784618@gmail.com',
        pass: 'kdlz zvcv zegp kgig',
      },
    });

    const mailOptions = {
      from: 's3784618@gmail.com',
      to: email,
      subject: 'Payment Receipt',
      text: 'Please find your payment receipt attached.',
      attachments: [
        {
          filename: 'payment_receipt.pdf',
          content: Buffer.from(pdfSlip, 'base64'),
          contentType: 'application/pdf',
        },
      ],
    };

    try {
      await transporter.sendMail(mailOptions);
    } catch (error) {
      console.error('Failed to send email:', error.message);
      throw new HttpException(
        'Failed to send payment slip to email',
        HttpStatus.INTERNAL_SERVER_ERROR,
      );
    }
  }
  async getPaymentsByUserId(userId: number): Promise<Payment[]> {
    return await this.paymentRepo.find({
      where: { patientId: userId }, // Fetch payments for the logged-in user
      order: { paymentDate: 'DESC' }, // Sort by latest payments
    });
  }

  async getAllPayments(): Promise<Payment[]> {
    return this.paymentRepo.find();
  }

}
