import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { TypeOrmModule } from '@nestjs/typeorm';
import { RegModule } from './reg/reg.module';
import { Registration } from './reg/reg.entity';
import { Appointment } from './appointment/appointment.entity';
import { Prescription } from './pescription/pescription.entity';
import { AppointmentModule } from './appointment/appointment.module';
import { PescriptionModule } from './pescription/pescription.module';
import { AuthModule } from './auth/auth.module';



@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'postgres',
      host: 'localhost',
      port: 5432,
      username: 'postgres',
      password: 'abcd',
      database: 'Patient',
      entities: [Registration, Appointment, Prescription],
      synchronize: true,
    }),
    RegModule,
    AppointmentModule,
    PescriptionModule,
    AuthModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
